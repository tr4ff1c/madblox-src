dofile("rbxasset://join.lua") 
dofile("rbxasset://character.lua") 
