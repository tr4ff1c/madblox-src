-- * This script handles the joining of games * --

dofile("rbxasset://ServerFiles\\IncludeScript.lua");

function CSConnectUI()
	local Defaults={Port=53640,IP="127.0.0.1",Username="Player",ValidColor=Color3.new(0,0.4,0),InvalidColor=Color3.new(0.4,0,0)}
	local IPBox,PortBox,NameBox,UI,UIMain,IPLabel,NameLabel,PortLabel,ConnectButton;
	local function ValidateData(Box)
		if (Box==IPBox) then
			if (Box.Text=="") then
				Box.Text=Defaults.IP;
			end
			return Box.Text:match("^(%d?%d?%d)%.(%d?%d?%d)%.(%d?%d?%d)%.(%d?%d?%d)");
		elseif (Box==PortBox) then
			if (Box.Text=="") then
				Box.Text=Defaults.Port;
			end
			return Box.Text:match("^(%d+)");
		elseif (Box==NameBox) then
			if (Box.Text=="") then
				Box.Text=Defaults.Username;
			end
			return true;
		end
	end
	local function SetColor(Box)
		if (ValidateData(Box)) then
			Box.BackgroundColor3=Defaults.ValidColor;
		else
			Box.BackgroundColor3=Defaults.InvalidColor;
		end
		if (ValidateData(IPBox)) and (ValidateData(PortBox)) then
			ConnectButton.Active=true;
			ConnectButton.TextColor3=Color3.new(1,1,1);
		else
			ConnectButton.Active=false;
			ConnectButton.TextColor3=Color3.new(0.7,0.7,0.7);
		end
	end
	UI=Instance.new("ScreenGui");
	UI.Parent=game:GetService("CoreGui");
	UI.Name="CSConnectUI";

	UIMain=Instance.new("Frame");
	UIMain.Parent=UI;
	UIMain.Size=UDim2.new(0,150,0,105);
	UIMain.Position=UDim2.new(0,0,0,100);
	UIMain.Style="RobloxRound";
	UIMain.Name="Main";

	IPLabel=Instance.new("TextLabel");
	IPLabel.Parent=UIMain;
	IPLabel.BackgroundTransparency=1;
	IPLabel.Size=UDim2.new(0,50,0,15);
	IPLabel.Text="IP:";
	IPLabel.TextColor3=Color3.new(1,1,1);
	IPLabel.TextXAlignment="Left";
	IPLabel.Name="IPLabel";

	PortLabel=Instance.new("TextLabel");
	PortLabel.Parent=UIMain;
	PortLabel.BackgroundTransparency=1;
	PortLabel.Size=UDim2.new(0,50,0,15);
	PortLabel.Position=UDim2.new(0,0,0,20);
	PortLabel.Text="Port:";
	PortLabel.TextColor3=Color3.new(1,1,1);
	PortLabel.TextXAlignment="Left";
	PortLabel.Name="PortLabel";

	NameLabel=Instance.new("TextLabel");
	NameLabel.Parent=UIMain;
	NameLabel.BackgroundTransparency=1;
	NameLabel.Size=UDim2.new(0,50,0,15);
	NameLabel.Position=UDim2.new(0,0,0,40);
	NameLabel.Text="Name:";
	NameLabel.TextColor3=Color3.new(1,1,1);
	NameLabel.TextXAlignment="Left";
	NameLabel.Name="NameLabel";

	IPBox=Instance.new("TextBox");
	IPBox.Parent=UIMain;
	IPBox.BackgroundTransparency=0.5;
	IPBox.Position=UDim2.new(0,40,0,0);
	IPBox.Size=UDim2.new(0,90,0,15);
	IPBox.TextXAlignment="Left";
	IPBox.BorderSizePixel=0;
	IPBox.BackgroundColor3=Defaults.ValidColor;
	IPBox.Text=Defaults.IP;
	IPBox.TextColor3=Color3.new(1,1,1);
	IPBox.Name="IPBox";
	IPBox.Changed:connect(function() SetColor(IPBox); end);

	PortBox=Instance.new("TextBox");
	PortBox.Parent=UIMain;
	PortBox.BackgroundTransparency=0.5;
	PortBox.Position=UDim2.new(0,40,0,20);
	PortBox.Size=UDim2.new(0,90,0,15);
	PortBox.TextXAlignment="Left";
	PortBox.BorderSizePixel=0;
	PortBox.BackgroundColor3=Defaults.ValidColor;
	PortBox.Text=Defaults.Port;
	PortBox.TextColor3=Color3.new(1,1,1);
	PortBox.Name="PortBox";
	PortBox.Changed:connect(function() SetColor(PortBox); end);

	NameBox=Instance.new("TextBox");
	NameBox.Parent=UIMain;
	NameBox.BackgroundTransparency=0.5;
	NameBox.Position=UDim2.new(0,40,0,40);
	NameBox.Size=UDim2.new(0,90,0,15);
	NameBox.TextXAlignment="Left";
	NameBox.BorderSizePixel=0;
	NameBox.BackgroundColor3=Defaults.ValidColor;
	NameBox.Text=Defaults.Username;
	NameBox.TextColor3=Color3.new(1,1,1);
	NameBox.Name="NameBox";
	NameBox.Changed:connect(function() SetColor(NameBox); end);

	ConnectButton=Instance.new("TextButton");
	ConnectButton.Parent=UIMain;
	ConnectButton.Position=UDim2.new(0.25,0,0,63);
	ConnectButton.Size=UDim2.new(0.5,0,0,20);
	ConnectButton.Style="RobloxButton";
	ConnectButton.TextColor3=Color3.new(1,1,1);
	ConnectButton.Text="Connect";
	ConnectButton.MouseButton1Click:connect(function()
		if (ConnectButton.Active==false) then return end
		UI:Remove();
		CSConnect(0,IPBox.Text,tonumber(PortBox.Text),NameBox.Text,"");
	end)
end

function CSConnect(UserID,ServerIP,ServerPort,PlayerName,Ticket,Limit)
	pcall(function()
		game:GetService("GuiService").Changed:connect(function()
			pcall(function() game:GetService("GuiService").ShowLegacyPlayerList=true; end);
			pcall(function() game.CoreGui.RobloxGui.PlayerListScript:Remove(); end);
			pcall(function() game.CoreGui.RobloxGui.PlayerListTopRightFrame:Remove(); end);
			pcall(function() game.CoreGui.RobloxGui.BigPlayerListWindowImposter:Remove(); end);
			pcall(function() game.CoreGui.RobloxGui.BigPlayerlist:Remove(); end);
		end);
	end)
	game:GetService("RunService"):Run();
	if (version()~="0, 3, 809, 0") then
		assert(pcall(game.HttpGet,game,"http://www.roblox.com/"),"CSConnect Error: Script cannot run at this security context.");
	end
	assert((ServerIP~=nil and ServerPort~=nil),"CSConnect Error: ServerIP and ServerPort must be defined.");
	local function SetMessage(Message) game:SetMessage(Message); end
	local Visit,NetworkClient,PlayerSuccess,Player,ConnectionFailedHook=game:GetService("Visit"),game:GetService("NetworkClient");

	local function GetClassCount(Class,Parent)
		local Objects=Parent:GetChildren();
		local Number=0;
		for Index,Object in pairs(Objects) do
			if (Object.className==Class) then
				Number=Number+1;
			end
			Number=Number+GetClassCount(Class,Object);
		end
		return Number;
	end

	local function RequestCharacter(Replicator)
		local Connection;
		Connection=Player.Changed:connect(function(Property)
			if (Property=="Character") then
				game:ClearMessage()
			end
		end)
		SetMessage("Progress: Requesting Character ...");
		Replicator:RequestCharacter()
		SetMessage("Progress: Waiting For Character ...");
	end

	local function Disconnection(Peer,LostConnection)
		if (LostConnection==true) then
			SetMessage("Error: Connection lost.");
		else
			SetMessage("Error: You were disconnected.");
		end
	end

	local function ConnectionAccepted(Peer,Replicator)
		Replicator.Disconnection:connect(Disconnection);
		local RequestingMarker=true;
		SetMessage("Progress: Loading Game ...");
		local Marker=Replicator:SendMarker();
		Marker.Received:connect(function()
			RequestingMarker=false;
			RequestCharacter(Replicator)
		end)
		while RequestingMarker do
			Workspace:ZoomToExtents()
			wait(0.5)
		end
	end

	local function ConnectionFailed(Peer,Code)
		SetMessage("Error: Connection failed. (ID="..Code..")");
	end

	pcall(function() settings().Diagnostics:LegacyScriptMode(); end);
	pcall(function() game:SetRemoteBuildMode(true); end);
	SetMessage("Progress: Connecting to the server ...")
	NetworkClient.ConnectionAccepted:connect(ConnectionAccepted)
	ConnectionFailedHook=NetworkClient.ConnectionFailed:connect(ConnectionFailed)
	NetworkClient.ConnectionRejected:connect(function()
		pcall(function() ConnectionFailedHook:disconnect(); end);
		SetMessage("Error: Connection Rejected.");
	end)

	pcall(function() NetworkClient.Ticket=Ticket or ""; end) -- 2008 client has no ticket :O
	if (Limit) then
		NetworkClient:SetOutgoingKBPSLimit(Limit)
	end
	PlayerSuccess,Player=pcall(function() return NetworkClient:PlayerConnect(UserID,ServerIP,ServerPort) end);

	if (not PlayerSuccess) then
		game:SetMessage("Error: " .. Player);
		wait(15)
	end

	if (not PlayerSuccess) then
		local Error,Message=pcall(function()
			Player=game:GetService("Players"):CreateLocalPlayer(UserID);
			NetworkClient:Connect(ServerIP,ServerPort);
		end);
		if (not Error) then
			SetMessage("Error: Connection failed");
		end
	end

	if (not Player) then
		SetMessage("Error: Local Player doesn't exist.");
		NetworkClient:Disconnect();
	end

	Player:SetSuperSafeChat(false);
	Player.CharacterAppearance="http://www.roblox.com/Asset/CharacterFetch.ashx?userId="..(UserID or 0);
	pcall(function() Player.Name=PlayerName or ""; end);
	pcall(function() Visit:SetUploadUrl(""); end);
end

coroutine.resume(coroutine.create(function()
	local Library=LoadLibrary("CSAPI");
	if (Library~=nil) then
		if (Library.CallFunction=="CSConnect") then
			CSConnect(unpack(Library.CallParams));
		end
		if (Library.CallFunction=="CSConnectUI") then
			CSConnectUI();
		end
	end
end))

_G.CSConnect=CSConnect;
_G.CSConnectUI=CSConnectUI;
