local JobId = 0;
local StatusUrl = "http://utilroblox.com/stooooof.php";
local ReportInterval = 15;
dofile("rbxasset://ServerFiles\\JSONLibrary.lua");
local JSONLibrary = _G.JSONLibrary;

function Request(Request)
	local Information = {
		RbxRAMUsage = math.floor(settings().Diagnostics.PrivateWorkingSetBytes/1024000);
		RbxMaxP = game:GetService("Players").MaxPlayers;
		RbxNumP = game:GetService("Players").NumPlayers;
		RbxJob = JobId;
		RbxRequest = Request;
	};
	for Index, Player in pairs(game:GetService("Players"):GetPlayers()) do
		Information[#Information + 1] = {UserId = Player.userId, Username = Player.Name};
	end
	local Data = JSONLibrary.EncodeJSON(Information);
	print(Data);
	game:HttpPost(StatusUrl, Data, true);
end

while true do
	wait(ReportInterval);
	Request("Update");
end

