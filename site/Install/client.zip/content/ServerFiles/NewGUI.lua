-- LocalChum

-- Still in beta, report any bugs.

coroutine.resume(coroutine.create(function()
local GameOptions = settings()["Game Options"];
GameOptions.VideoCaptureEnabled = true;
GameOptions.VideoQuality = "High Resolution"; -- :3
--error()
-- Preferences
local UIHeight = 15;
-- Start UI loader
local RbxGui = LoadLibrary("RbxGui"); -- RbxGui UI API
local CoreGui = game:GetService("CoreGui");
local RobloxGui = nil;
for Index,Child in pairs(CoreGui:GetChildren()) do
	if (Child.Name == "RobloxGui") then
		RobloxGui = Child;
	end
	--Child:Remove();
end
local DialogOpen = false;
local UI = Instance.new("ScreenGui");
UI.Name = "GuiMain";
UI.Parent = CoreGui;

-- Functions
function TweenOut(GUI)
	for Index,Child in pairs(GUI:GetChildren()) do
		Child.Parent = nil;
	end
	GUI:TweenSizeAndPosition(UDim2.new(0,0,0,0),UDim2.new(0.5,0,0.5,0),"Out","Quad",0.2,false,function() GUI:Remove() end)
end

function ShowExitDialog()
	if (DialogOpen) then return end
	DialogOpen = true;
	local MessageDialog; -- We need that or else the variable won't show up
	MessageDialog = RbxGui.CreateStyledMessageDialog(
		"Exit",
		"Are you sure you want to exit the current game?", -- "Exit" sounds more professional than "Leave" (Maybe they dumbed down the HUD >:O)
		"Confirm",
		{
			{
				Text = "OK",
				Function = function() --[[MessageDialog:Remove();]]TweenOut(MessageDialog); game:Shutdown(); DialogOpen = false; end -- Exit
			},
			{
				Text = "Cancel",
				Function = function() --[[MessageDialog:Remove();]]TweenOut(MessageDialog) DialogOpen = false; end -- Do nothing
			}
		}
	);
	MessageDialog.Parent = UI;
end

function ShowAboutDialog()
	if (DialogOpen) then return end
	DialogOpen = true;
	local MessageDialog;
	MessageDialog = RbxGui.CreateStyledMessageDialog(
		"About",
		"RBXPri is an ongoing project started by Popinman322 and maintained by Blocco and LocalChum.",
		"Notify", -- :U
		{
			{
				Text = "OK",
				Function = function() --[[MessageDialog:Remove();]]TweenOut(MessageDialog); DialogOpen = false; end
			}
		}
	);
	MessageDialog.Parent = UI;
end

--[[ function ShowVideoQualityDialog()
	if (DialogOpen) then return end
	DialogOpen = true;
	local MessageDialog;
	MessageDialog = RbxGui.CreateStyledMessageDialog(
		"Video Quality",
		"Quality:",
		"Notify",
		{
			{
				Text = "OK",
				Function = function() TweenOut(MessageDialog); DialogOpen = false; end
			}
		}
	);
	local QualityBox = RbxGui.CreatePropertyDropDownMenu(GameOptions,"VideoQuality",Enum.VideoQualitySettings);
	QualityBox.Size = UDim2.new(0.5,0,0,20);
	QualityBox.Position = UDim2.new(0.4,0,0,45);
	QualityBox.Parent = MessageDialog;
	MessageDialog.Parent = UI;
end ]]

function CreateButtons(Frame, Buttons)
	for Index,Table in pairs(Buttons) do
		local Button = Instance.new("TextButton")
		--Button.Style = "RobloxButtonDefault";
		Button.Name = "Button";
		Button.Size = UDim2.new(1/#Buttons,0,0,UIHeight);
		Button.Position = UDim2.new((Index - 1) / #Buttons,0,0,0);
		Button.MouseButton1Click:connect(Table.Callback);
		Button.Text = Table.Text;
		Button.Parent = Frame;
		Button.BorderColor3 = Color3.new(0.5,0.5,0.5);
		Button.TextColor3 = Color3.new(1,1,1);
		Button.BackgroundTransparency = 0.7;
		Button.BackgroundColor3 = Color3.new(0.7,0.7,0.7);
		if (Table.Finalize) then
			Table.Finalize(Button);
		end
	end
end

function FuseButton(RbxButtonName, Button, ClickFire)
	local RbxButton = RobloxGui.BottomRightControl:FindFirstChild(RbxButtonName);
	if (RbxButton == nil) then
		RbxButton = RobloxGui.BottomLeftControl:FindFirstChild(RbxButtonName);
	end
	RbxButton.BackgroundTransparency = 1;
	RbxButton.Image = "";
	RbxButton.Style = "Custom";
	RbxButton.Size = UDim2.new(1,0,1,0);
	RbxButton.Position = UDim2.new(0,0,0,0);
	RbxButton.Name = "CaptureButton";
	RbxButton.Parent = Button
	pcall(function()
		RbxButton.ToolTip:Remove();
	end)
	if (ClickFire) then
		RbxButton.MouseButton1Click:connect(ClickFire);
	end
end

-- Make the GUI
local Frame = Instance.new("Frame");
Frame.Name = "CenterButton";
-- Frame.Style = "RobloxRound";
Frame.Position = UDim2.new(0.20,0,0,0);
Frame.Size = UDim2.new(0.60,0,0,UIHeight);
Frame.BorderSizePixel = 0;
Frame.BackgroundTransparency = 0.7;
Frame.BackgroundColor3 = Color3.new(0.9,0.9,0.9);
Frame.Parent = UI;
CreateButtons(Frame,
	{
		{
			Text = "Exit",
			Callback = ShowExitDialog
		},
		{
			Text = "About",
			Callback = ShowAboutDialog
		},
		{
			Text = "Studio",
			Callback = function() end,
			Finalize = function(Button) FuseButton("TogglePlayMode",Button); end
		},
		{
			Text = "Start Rec",
			Callback = function() end,
			Finalize = function(Button)
				FuseButton("RecordToggle",Button,function()
					if (Button.Text == "Start Rec") then
						Button.Text = "Stop Rec";
					else
						Button.Text = "Start Rec";
					end
				end)
			end
		},
		{
			Text = "Screenshot",
			Callback = function() end,
			Finalize = function(Button)
				FuseButton("Screenshot",Button);
			end
		},
		--[[ {
			Text = "Video Quality",
			Callback = ShowVideoQualityDialog
		}, ]]
		{
			Text = "Fullscreen",
			Callback = function() end,
			Finalize = function(Button)
				FuseButton("ToggleFullScreen",Button);
			end
		}
	}
);

for Index,Child in pairs(CoreGui:GetChildren()) do
	if (Child ~= UI) then
		Child:Remove();
	end
end

end))
