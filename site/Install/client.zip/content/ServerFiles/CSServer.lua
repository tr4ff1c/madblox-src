-- * This script starts a server. * --

dofile("rbxasset://ServerFiles\\IncludeScript.lua");

EnforceMaxPlayers=false;
SysopConnections={};
IPBannedlist={};

function IncommingConnection(Peer, Replicator)
	print(Replicator.MachineAddress,"is in my mouth");
	for Index,Value in pairs(IPBannedlist) do
		if (Value == Replicator.MachineAddress) then
			Replicator:CloseConnection();
		end
	end
end

function CSServer(Port,Limit)
	if (version()~="0, 3, 809, 0") then
		assert(pcall(game.SetRemoteBuildMode,game,game:GetRemoteBuildMode()),"CSRun Error: Script cannot run at this security context.");
	end
	assert((type(Port)~="number" or tonumber(Port)~=nil or Port==nil),"CSRun Error: Port must be nil or a number.");
	local NetworkServer=game:GetService("NetworkServer");
	if (Limit) then
		NetworkServer:SetOutgoingKBPSLimit(Limit)
	end
	pcall(NetworkServer.Stop,NetworkServer);
	NetworkServer:Start(Port);
	game:GetService("Players").PlayerAdded:connect(function(Player)
		if (version()=="0, 3, 809, 0") then -- RequestCharacter fails in this client...
			Player:LoadCharacter();
		end
		Player.Changed:connect(function(Property)
			if (Property=="Character") and (Player.Character~=nil) then
				local Character=Player.Character;
				local Humanoid=Character:FindFirstChild("Humanoid");
				if (Humanoid~=nil) then
					Humanoid.Died:connect(function() delay(5,function() Player:LoadCharacter() end) end)
				end
			end
		end)
	end)
	game:GetService("RunService"):Run();
	pcall(function() game.Close:connect(function() NetworkServer:Stop(); end) end);
	-- ChildAdded is being a retard. Sorry for inefficient code.
	--[[while wait(0.1) do
		print("OMG",#game.NetworkServer:children())
		for Index,Child in pairs(NetworkServer:GetChildren()) do
			if (Child.className == "") then
				IncommingConnection(nil, Child);
			end
		end
	end]]
	NetworkServer.IncommingConnection:connect(IncommingConnection);
end

function CSAddSysop(Player)
	assert(pcall(game.SetRemoteBuildMode,game,game:GetRemoteBuildMode()),"CSAddSysop Error: Script cannot run at this security context.");
	if (type(Player)~="userdata") then
		for Index,NewPlayer in pairs(game:GetService("Players"):GetPlayers()) do
			CSAddSysop(NewPlayer);
		end
		return false;
	end
	if (SysopConnections[Player]==nil) then
		SysopConnections[Player]=Player.Chatted:connect(function(Message)
			if (Message:sub(1,2)=="s/") then
				coroutine.resume(coroutine.create(function() loadstring(Message:sub(3))(); end));
			end
			if (Message:sub(1,6)=="ipban/") then
				local IP = Message:sub(7);
				for Index,Replicator in pairs(game:GetService("NetworkServer"):GetChildren()) do
					if (Replicator:IsA("NetworkReplicator")) then
						if (Replicator.MachineAddress == IP) or (Replicator:GetPlayer().Name:lower() == IP:lower()) then
							IPBannedlist[#IPBannedlist+1] = Replicator.MachineAddress;
							IncommingConnection(nil, Replicator);
						end
					end
				end
			end
		end);
	end
	return true;
end

_G.CSAddSysop=CSAddSysop
_G.CSServer=CSServer;
coroutine.resume(coroutine.create(function()
	local Library=LoadLibrary("CSAPI");
	if (Library~=nil) then
		if (Library.CallFunction=="CSServer") then
			CSServer(unpack(Library.CallParams));
		end
		if (Library.CallFunction=="CSAddSysop") then
			CSAddSysop(unpack(Library.CallParams));
		end
	end
end))

