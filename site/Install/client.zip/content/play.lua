dofile("rbxasset://character.lua") 
dofile("rbxasset://join.lua") 
