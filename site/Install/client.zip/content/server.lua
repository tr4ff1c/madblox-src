dofile('rbxasset://host.lua') 
game:Load('rbxasset://gui.rbxm') 
game:FindFirstChild("Health-GUI").Parent = game.StarterGui 
